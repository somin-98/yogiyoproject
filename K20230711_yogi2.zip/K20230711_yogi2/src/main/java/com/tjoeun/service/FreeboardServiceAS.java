package com.tjoeun.service;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import com.tjoeun.dao.FreeboardDAOAS;
import com.tjoeun.mybatis.MySession;
import com.tjoeun.vo.RegisterVO;

public class FreeboardServiceAS {

	private static FreeboardServiceAS instance = new FreeboardServiceAS();
	private FreeboardServiceAS() { }
	public static FreeboardServiceAS getInstance() {
		return instance;
	}
	
	public static void register(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("FreeboardServiceAS의 register()");
		try {
			SqlSession mapper = MySession.getSession();
			System.out.println(mapper);
			RegisterVO ro = new RegisterVO();
			ro.setUserid(request.getParameter("userID"));
			ro.setUserpassword(request.getParameter("userPassword1"));
			ro.setUsername(request.getParameter("userName"));
			ro.setUserage(Integer.parseInt(request.getParameter("userAge")));
			ro.setUsergender(request.getParameter("userGender"));
			ro.setUseremail(request.getParameter("userEmail"));
			System.out.println(ro);
			FreeboardDAOAS.getInstance().register(mapper, ro);
			mapper.commit();
			mapper.close();	
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	

}






