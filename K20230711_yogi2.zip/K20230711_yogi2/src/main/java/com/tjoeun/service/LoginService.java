package com.tjoeun.service;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import com.tjoeun.dao.LoginDAO;
import com.tjoeun.mybatis.MySession;
import com.tjoeun.vo.LoginVO;

public class LoginService {

	private static LoginService instance = new LoginService();
	private LoginService() { }
	public static LoginService getInstance() {
		return instance;
	}
	
	public LoginVO selectByIdxLogin(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("LoginService의 selectByIdx()");
		SqlSession mapper = MySession.getSession();
		
		LoginDAO dao = LoginDAO.getInstance();
		/*
		 * HashMap<String, String> hmap = new HashMap<>(); hmap.put("userid",
		 * (request.getParameter("userid").trim()));
		 * 
		 * // hmap.put("userpassword", request.getParameter("userpassword").trim());
		 * System.out.println(hmap); LoginVO lo = dao.selectByIdxLogin(mapper, hmap);
		 */
		LoginVO inputLo = new LoginVO();
		inputLo.setUserid(request.getParameter("userid").trim());
		inputLo.setUserpassword(request.getParameter("userpassword").trim());
		LoginVO lo = dao.selectByIdxLogin(mapper, inputLo);
		System.out.println(lo);
		
		mapper.close();
		return lo;
	}

}






