package com.tjoeun.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tjoeun.service.ASNCommentService;
import com.tjoeun.service.ASNService;
import com.tjoeun.vo.FreeboardASNVO;
import com.tjoeun.vo.FreeboardListASN;

@WebServlet("/ASListController")
public class ASListController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ASListController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		actionDo(request, response);
	}

	protected void actionDo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("ASListController 클래스의 actionDo() 메소드");

		// 한글 깨짐 방지
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");

		// view 페이지 경로 만들기
		String viewpage = "/WEB-INF/";

//		이전 페이지에서 넘어오는 화면에 표시할 페이지 번호를 받는다.
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(request.getParameter("currentPage"));
		} catch (NumberFormatException e) {

		}
		ASNService service = ASNService.getInstance();
		ASNCommentService commentService = ASNCommentService.getInstance();

//		모든 공지글을 얻어온다.
		ArrayList<FreeboardASNVO> notice = service.selectNoticeASN();
		// 1페이지 분량의 메인글을 얻어온다. 
		FreeboardListASN freeboardListAsn =	service.selectListASN(currentPage);
		 
		 // 공지글과 메인글의 댓글 개수를 얻어와서 FreeboardVO 클래스의 commentCount에 저장한다. 
		for  (FreeboardASNVO ao : notice) {
		ao.setCommentCount(commentService.commentCount(ao.getIdx())); } 
		 for (FreeboardASNVO ao : freeboardListAsn.getList()) {
		 ao.setCommentCount(commentService.commentCount(ao.getIdx())); }
		 
		 // 공지글과 메인글의 목록을 request 영역에 저장해서 메인글을 화면에 표시하는 페이지(listView.jsp)로 넘겨준다.
		 request.setAttribute("notice", notice);
		 request.setAttribute("freeboardListAsn", freeboardListAsn);
		 request.setAttribute("currentPage", currentPage);
		 
		 viewpage += "listView.jsp"; // System.out.println(viewpage);
		
		// view 페이지로 넘기기
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewpage);
		dispatcher.forward(request, response);
	}

}
