package com.tjoeun.controller;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tjoeun.service.ASNCommentService;
import com.tjoeun.service.ASNService;
import com.tjoeun.vo.FreeboardASNVO;
import com.tjoeun.vo.FreeboardCommentListASN;

@WebServlet("/ASNincrementController")
public class ASNincrementController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ASNincrementController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}
	
	protected void actionDo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("ASNincrementController 클래스의 actionDo() 메소드");
		
		// 한글 깨짐 방지
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// view 페이지 경로 만들기
		String viewpage = "/WEB-INF/";

//		listView.jsp에서 넘어오는 조회수를 증가시킬 글번호와 메인글 확인 후 돌아갈 페이지 번호를 받는다.
		int idx = Integer.parseInt(request.getParameter("idx"));
		int currentPage = Integer.parseInt(request.getParameter("currentPage"));
		System.out.println(currentPage);
		System.out.println(idx);
		
//		조회수를 증가시키는 메소드를 실행한다.
		ASNService.getInstance().increment(idx);

//		increment.jsp 또는 contentView.jsp에서 넘어오는 글번호, 돌아갈 페이지 번호, 분기할 페이지 이름를 받는다.
		
//		메인글 1건을 얻어오는 메소드를 호출한다.
		FreeboardASNVO vo = ASNService.getInstance().selectByIdx(idx);
//		out.println(vo);

//		브라우저에 출력할 메인글이 저장된 객체, 작업 후 돌아갈 페이지 번호, 줄바꿈에 사용할 이스케이프 
//		시퀀스(\r\n)를 request 영역에 저장한다.
		request.setAttribute("vo", vo);
		request.setAttribute("currentPage", currentPage);
		request.setAttribute("enter", "\r\n");
		
//		job에 contentView가 넘어왔을 경우 댓글 목록을 얻어와서 request 영역에 저장시킨다.
		FreeboardCommentListASN freeboardCommentList = 
				ASNCommentService.getInstance().selectCommentList(idx);
		request.setAttribute("freeboardCommentList", freeboardCommentList);
		
		viewpage += "contentView.jsp";
		
		// view 페이지로 넘기기
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewpage);
		dispatcher.forward(request, response);
	}

}

