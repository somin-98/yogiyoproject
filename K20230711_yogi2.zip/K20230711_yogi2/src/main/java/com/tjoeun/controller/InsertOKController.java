package com.tjoeun.controller;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tjoeun.service.ASNService;
import com.tjoeun.vo.FreeboardASNVO;

@WebServlet("/InsertOKController")
public class InsertOKController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	public InsertOKController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}
	
	protected void actionDo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("InsertOKController 클래스의 actionDo() 메소드");
		
		// 한글 깨짐 방지
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// view 페이지 경로 만들기
		String viewpage = "/WEB-INF/";
		
		// 꺼내는 작업
	/*	<jsp:useBean id="vo" class="com.tjoeun.vo.FreeboardVO">
			<jsp:setProperty property="*" name="vo"/>
		</jsp:useBean>
		${vo}
		
	<%*/
		
		FreeboardASNVO vo = new FreeboardASNVO();
		// vo.setIdx(request.getParameter("idx"));
		vo.setName(request.getParameter("name"));
		vo.setPassword(request.getParameter("password"));
		vo.setContent(request.getParameter("content"));
		vo.setSubject(request.getParameter("subject"));
		if (request.getParameter("notice") == null) {
			vo.setNotice("");
		} else {
			vo.setNotice(request.getParameter("notice"));
		}
		vo.setIp(request.getParameter("ip"));
		// vo.setIp("");
		System.out.println(vo);
		// name, password, subject, content, notice, ip
		
//		insert.jsp에서 넘어온 메인글을 테이블에 저장하는 메소드를 실행한다.
		ASNService.getInstance().insert(vo);
//		메인글 1페이지 분량의 글 목록을 얻어오는 페이지(list.jsp)로 넘겨준다.
		response.sendRedirect("list.jsp");
		
		viewpage += "ASListController";
		// System.out.println(viewpage);
		
		// view 페이지로 넘기기
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewpage);
		dispatcher.forward(request, response);
	}

}









