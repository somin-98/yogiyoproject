package com.tjoeun.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tjoeun.service.LoginService;
import com.tjoeun.vo.LoginVO;

@WebServlet("/LoginActionController")
public class LoginActionController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public LoginActionController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}

	protected void actionDo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("LoginActionController 클래스의 actionDo() 메소드");
		
		// 한글 깨짐 방지
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// view 페이지 경로 만들기
		String viewpage = "/WEB-INF/";
		
		String password = request.getParameter("userpassword").trim();
		System.out.println("password: " + password + "userid: " + request.getParameter("userid"));
		LoginService service = LoginService.getInstance();
		LoginVO lo = service.selectByIdxLogin(request, response);
		System.out.println(lo);
		
		
		if (lo.getUserpassword().trim().equals(password)) {
			// 성공시 로그인
			System.out.println("로그인 성공");
		} else {
			// 실패시 로그인 페이지
			System.out.println("로그인 실패");
		}
		viewpage += "index.jsp";
		
		// view 페이지로 넘기기
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewpage);
		dispatcher.forward(request, response);
	}
	
	
}
