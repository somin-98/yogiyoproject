package com.tjoeun.vo;

//	메인글 1건을 기억하는 클래스
public class LoginVO {

	private String userid;
	private String userpassword;
	private String username; // 메인글 제목
	private int userage; // 조회수
	private String usergender = ""; // 공지글 여부(on => 공지글, "" => 일반글)
	private String usermail;
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUserpassword() {
		return userpassword;
	}
	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getUserage() {
		return userage;
	}
	public void setUserage(int userage) {
		this.userage = userage;
	}
	public String getUsergender() {
		return usergender;
	}
	public void setUsergender(String usergender) {
		this.usergender = usergender;
	}
	public String getUsermail() {
		return usermail;
	}
	public void setUsermail(String usermail) {
		this.usermail = usermail;
	}
	
	@Override
	public String toString() {
		return "LoginVO [userid=" + userid + ", userpassword=" + userpassword + ", username=" + username + ", userage="
				+ userage + ", usergender=" + usergender + ", usermail=" + usermail + "]";
	}
	
	
	
}
