package com.tjoeun.vo;

import java.util.ArrayList;

//	댓글 목록을 기억하는 클래스
public class FreeboardCommentListASN {

	private ArrayList<FreeboardCommentASNVO> list = new ArrayList<>();

	public ArrayList<FreeboardCommentASNVO> getList() {
		return list;
	}

	public void setList(ArrayList<FreeboardCommentASNVO> list) {
		this.list = list;
	}

	@Override
	public String toString() {
		return "FreeboardCommentListASN [list=" + list + "]";
	}

	
}
