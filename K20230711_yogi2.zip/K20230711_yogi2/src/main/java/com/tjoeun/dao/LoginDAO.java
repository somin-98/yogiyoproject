package com.tjoeun.dao;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;

import com.tjoeun.vo.LoginVO;

public class LoginDAO {

	private static LoginDAO instance = new LoginDAO();
	private LoginDAO() { }
	public static LoginDAO getInstance() {
		return instance;
	}
	
	/*
	 * public LoginVO selectByIdxLogin(SqlSession mapper, HashMap<String, String>
	 * hmap) { System.out.println("LoginDAO의 selectByIdx()"); return (LoginVO)
	 * mapper.selectOne("selectByIdxLogin", hmap);
	 * 
	 * 
	 * }
	 */
	
	public LoginVO selectByIdxLogin(SqlSession mapper, LoginVO inputLo) {
		System.out.println("LoginDAO의 selectByIdx()");
		return (LoginVO) mapper.selectOne("selectByIdxLogin", inputLo);
	}
	public LoginVO selectByIdxLogin(HttpSession mapper, LoginVO inputLo) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
