package com.tjoeun.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;

import com.tjoeun.vo.FreeboardASNVO;
import com.tjoeun.vo.FreeboardCommentASNVO;

public class ASNCommentDAO {

	private static ASNCommentDAO instance = new ASNCommentDAO();
	private ASNCommentDAO() { }
	public static ASNCommentDAO getInstance() {
		return instance;
	}
	
//	FreeboardService 클래스에서 호출되는 mapper와 메인글이 저장된 객체를 넘겨받고 freeboard.xml 파일의
//	insert sql 명령을 실행하는 메소드
	public void insert(SqlSession mapper, FreeboardASNVO vo) {
		System.out.println("ASNDAO의 insert()");
		mapper.insert("insertASN", vo);
	}
	
//	FreeboardService 클래스에서 호출되는 mapper를 넘겨받고 메인글 전체 개수를 얻어오는 freeboard.xml 파일의
//	select sql 명령을 실행하는 메소드
	public int selectCountASN(SqlSession mapper) {
		System.out.println("ASNDAO의 selectCountASN()");
		return (int) mapper.selectOne("selectCountASN");
	}
	
//	FreeboardService 클래스에서 호출되는 mapper와 1페이지 분량의 시작 인덱스, 끝 인덱스가 저장된 HashMap 객체를
//	넘겨받고 1페이지 분량의 메인글 목록을 얻어오는 freeboard.xml 파일의 select sql 명령을 실행하는 메소드
	public ArrayList<FreeboardASNVO> selectListASN(SqlSession mapper, HashMap<String, Integer> hmap) {
		System.out.println("ASNDAO의 selectListASN()");
		return (ArrayList<FreeboardASNVO>) mapper.selectList("selectListASN", hmap);
	}
	
//	FreeboardService 클래스에서 호출되는 mapper와 조회수를 증가시킬 글번호를 넘겨받고 조회수를 증가시키는
//	freeboard.xml 파일의 update sql 명령을 실행하는 메소드
	public void increment(SqlSession mapper, int idx) {
		System.out.println("ASNDAO의 increment()");
		mapper.update("increment", idx);
	}
	
//	FreeboardService 클래스에서 호출되는 mapper와 조회수를 증가시킨 글번호를 넘겨받고 조회수를 증가시킨
//	글 1건을 얻어오는 freeboard.xml 파일의 select sql 명령을 실행하는 메소드
	public FreeboardASNVO selectByIdx(SqlSession mapper, int idx) {
		System.out.println("ASNDAO의 selectByIdx()");
		return (FreeboardASNVO) mapper.selectOne("selectByIdx", idx);
	}
	
//	FreeboardService 클래스에서 호출되는 mapper와 삭제할 메인글의 글번호를 넘겨받고 메인글 1건을 삭제하는
//	freeboard.xml 파일의 delete sql 명령을 실행하는 메소드
	public void delete(SqlSession mapper, int idx) {
		System.out.println("ASNDAO의 delete()");
		mapper.delete("delete", idx);
	}
	
//	FreeboardService 클래스에서 호출되는 mapper와 삭제할 정보가 저장된 객체를 넘겨받고 메인글 1건을 수정하는
//	freeboard.xml 파일의 update sql 명령을 실행하는 메소드
	public void update(SqlSession mapper, FreeboardASNVO vo) {
		System.out.println("ASNDAO의 update()");
		mapper.update("update", vo);
	}
	
//	FreeboardService 클래스에서 호출되는 mapper를 넘겨받고 모든 공지글 목록을 얻어오는 freeboard.xml 파일의 
//	update sql 명령을 실행하는 메소드 
	public ArrayList<FreeboardASNVO> selectNoticeASN(SqlSession mapper) {
		System.out.println("ASNDAO의 selectNoticeASN()");
		return (ArrayList<FreeboardASNVO>) mapper.selectList("selectNoticeASN");
	}
	
	public int commentCountASN(SqlSession mapper, int idx) {
		System.out.println("ASNCommentDAO의 commentCountASN()");
		return (int) mapper.selectOne("commentCountASN", idx);
	}
	
	public ArrayList<FreeboardCommentASNVO> selectCommentListASN(SqlSession mapper, int idx) {
		System.out.println("ASNCommentDAO의 selectCommentListASN()");
		return (ArrayList<FreeboardCommentASNVO>) mapper.selectList("selectCommentListASN", idx);
	}
	
//	FreeboardCommentService 클래스에서 호출되는 mapper와 댓글 데이터가 저장된 객체를 넘겨받고 댓글을 저장하는
//	freeboardcomment.xml 파일의 insert sql 명령을 실행하는 메소드
	public int insertComment(SqlSession mapper, FreeboardCommentASNVO co) {
		System.out.println("FreeboardCommentDAO의 insertComment()");
		// insert, delete, update sql 명령의 실행 결과를 리턴시키면 sql 명령이 성공적으로 실행된 횟수가
		// 리턴된다.
		return mapper.insert("insertComment", co);
	}
	
//	FreeboardCommentService 클래스에서 호출되는 mapper와 메인글의 글번호를 넘겨받고 댓글의 개수를 얻어오는
//	freeboardcomment.xml 파일의 select sql 명령을 실행하는 메소드
	public int commentCount(SqlSession mapper, int idx) {
		System.out.println("FreeboardCommentDAO의 commentCount()");
		return (int) mapper.selectOne("commentCount", idx);
	}
	
//	FreeboardCommentService 클래스에서 호출되는 mapper와 메인글의 글번호를 넘겨받고 메인글의 댓글 목록을
//	얻어오는 freeboardcomment.xml 파일의 select sql 명령을 실행하는 메소드
	public ArrayList<FreeboardCommentASNVO> selectCommentList(SqlSession mapper, int idx) {
		System.out.println("ASNCommentDAO의 selectCommentList()");
		return (ArrayList<FreeboardCommentASNVO>) mapper.selectList("selectComentList", idx);
	}
	
//	FreeboardCommentService 클래스에서 호출되는 mapper와 댓글의 글번호를 넘겨받고 댓글 1건을 얻어오는 
//	freeboardcomment.xml 파일의 select sql 명령을 실행하는 메소드
	public FreeboardCommentASNVO selectCommentByIdx(SqlSession mapper, int idx) {
		System.out.println("ASNCommentDAO의 selectCommentByIdx()");
		return (FreeboardCommentASNVO) mapper.selectOne("selectCommentByIdx", idx);
	}
	
//	FreeboardCommentService 클래스에서 호출되는 mapper와 댓글을 수정할 정보가 저장된 객체를 넘겨받고 댓글
//	1건을 수정하는 freeboardcomment.xml 파일의 update sql 명령을 실행하는 메소드
	public void updateComment(SqlSession mapper, FreeboardCommentASNVO co) {
		System.out.println("ASNCommentDAO의 updateComment()");
		mapper.update("updateComment", co);
	}
	
//	FreeboardCommentService 클래스에서 호출되는 mapper와 댓글을 삭제할 정보가 저장된 객체를 넘겨받고 댓글
//	1건을 삭제하는 freeboardcomment.xml 파일의 delete sql 명령을 실행하는 메소드
	public void deleteComment(SqlSession mapper, FreeboardCommentASNVO co) {
		System.out.println("ASNCommentDAO의 updateComment()");
		mapper.delete("deleteComment", co);
	}
	
	
	
}
