package com.tjoeun.dao;

import org.apache.ibatis.session.SqlSession;

import com.tjoeun.vo.RegisterVO;

public class FreeboardDAOAS {

	private static FreeboardDAOAS instance = new FreeboardDAOAS();
	private FreeboardDAOAS() { }
	public static FreeboardDAOAS getInstance() {
		return instance;
	}
	
	public void register(SqlSession mapper, RegisterVO ro) {
		System.out.println("FreeboardDAOAS의 register()");
		mapper.insert("register", ro);
	}
	
}
